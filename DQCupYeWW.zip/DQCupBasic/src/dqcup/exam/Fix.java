package dqcup.exam;

public class Fix {

	public Fix(Find find)
	{
		
	}
}
